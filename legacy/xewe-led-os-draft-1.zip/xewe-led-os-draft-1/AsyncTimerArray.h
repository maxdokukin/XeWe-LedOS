#ifndef ASYNCTIMERARRAY_H
#define ASYNCTIMERARRAY_H

#include <cstdint>
#include <Arduino.h>
#include <array>

class AsyncTimerArray{

private:
    uint32_t start_time, end_time, delay;
    uint8_t start_val[3], end_val[3];
    bool done = false, initiated = false, debug = false;
    double progress = 0;

public:
    // Constructor with delay only
    AsyncTimerArray(uint32_t delay, bool debug = false)
        : delay(delay), start_time(millis()), end_time(start_time + delay), debug(debug) {
        memset(this->start_val, 0, 3);
        memset(this->end_val, 0, 3);
        if (this->debug) {
            Serial.print("AsyncTimerArray<uint8_t[3]> initialized with delay: ");
            Serial.println(delay);
        }
    }

    // Constructor with delay, start_val, and end_val
    AsyncTimerArray(uint32_t delay, const uint8_t start_val[3], const uint8_t end_val[3], bool debug = false)
        : delay(delay), start_time(millis()), end_time(start_time + delay), debug(debug) {
        memcpy(this->start_val, start_val, 3);
        memcpy(this->end_val, end_val, 3);
        if (this->debug) {
            Serial.print("AsyncTimerArray<uint8_t[3]> initialized with delay: ");
            Serial.print(this->delay);
            Serial.print(", start_val: ");
            for (int i = 0; i < 3; ++i){

                Serial.print(this->start_val[i]); 
                Serial.print(", ");
            }
            Serial.print(", end_val: ");
            for (int i = 0; i < 3; ++i){
                Serial.print(this->end_val[i]); 
                Serial.print(", ");
            }
            Serial.println();
        }
    }

    // Method to get progress as float
    void calculate_progress(){
        this->progress = (millis() - start_time) / static_cast<double>(delay);
        if (progress > 1.0) {
            this->done = true;
            progress = 1;
        }
    }

    float get_progress() {
        this->calculate_progress();
        if (this->debug) {
            Serial.print("ArrayTimer.get_progress: Progress: ");
            Serial.println(progress);
        }
        return progress;
    }

    std::array<uint8_t, 3> get_current_value() {
        std::array<uint8_t, 3> current_val;
        for (int i = 0; i < 3; ++i) {
            current_val[i] = static_cast<uint8_t>(this->start_val[i] + (this->end_val[i] - this->start_val[i]) * this->progress);
        }
        if (debug) {
            Serial.print("ArrayTimer.get_current_value: Current value: ");
            for (int i = 0; i < 3; ++i) Serial.print(current_val[i]);
            Serial.println();
        }
        return current_val;
    }

    // Method to check if the timer is done
    bool is_done() {
        this->get_progress();
        if (this->debug) {
            Serial.print("Timer done: ");
            Serial.println(done);
        }
        return this->done;
    }

    // Method to check if the timer is active
    bool is_active() {
        this->get_progress();
        if (this->debug) {
            Serial.print("Timer active: ");
            Serial.println(!done);
        }
        return !this->done;
    }

    bool is_initiated() {
        if (this->debug) {
            Serial.print("Timer initiated: ");
            Serial.println(initiated);
        }
        return this->initiated;
    }

    bool is_not_initiated() {
        if (this->debug) {
            Serial.print("Timer not initiated: ");
            Serial.println(!this->initiated);
        }
        return !this->initiated;
    }

    void initiate() {
        this->initiated = true;
        if (this->debug) {
            Serial.println("Timer initiated");
        }
    }

    // Method to reset the timer
    void reset() {
        this->start_time = millis();
        this->end_time = this->start_time + this->delay;
        this->done = false;
        this->initiated = false;
        if (this->debug) {
            Serial.println("Timer reset");
        }
    }

    // Method to reset the timer with new parameters
    void reset(uint32_t new_delay) {
        this->delay = new_delay;
        reset();
        if (this->debug) {
            Serial.print("with new delay: ");
            Serial.println(new_delay);
        }
    }

    // Method to reset the timer with new parameters
        // Method to reset the timer with new parameters
    void reset(uint32_t new_delay, const uint8_t new_start_val[3], const uint8_t new_end_val[3]) {
        this->delay = new_delay;
        memcpy(this->start_val, new_start_val, 3);
        memcpy(this->end_val, new_end_val, 3);
        reset();
        if (debug) {
            Serial.print("ArrayTimer reset with new delay: ");
            Serial.print(new_delay);
            Serial.print(", new start_val: ");
            for (int i = 0; i < 3; ++i){
                Serial.print(this->start_val[i]); 
                Serial.print(", ");
            }
            Serial.print(", new end_val: ");
            for (int i = 0; i < 3; ++i){
                Serial.print(this->end_val[i]); 
                Serial.print(", ");
            }
            Serial.println();
        }
    }
};

#endif // ASYNCTIMERARRAY_H
