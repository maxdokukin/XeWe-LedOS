#include "DirectionalFiller.h"

DirectionalFiller::DirectionalFiller(LedController *parent_controller)
    : parent_controller(parent_controller) {
    timer = new AsyncTimer<uint32_t>(0);
}

void DirectionalFiller::frame() {
    fill_directional(timer->get_progress());
}

bool DirectionalFiller::is_done() {
    return timer->is_done();
}

void DirectionalFiller::set_target(uint8_t r, uint8_t g, uint8_t b, int start_led, int end_led, uint16_t delay, char direction) {
    this->r = r;
    this->g = g;
    this->b = b;
    this->start_led = start_led;
    this->end_led = end_led;
    this->direction = direction;
    this->timer->reset(delay);
}

bool DirectionalFiller::fill_directional(double progress) {
    uint16_t led_delta = abs(start_led - end_led) + 1;
    if (led_delta == 0) return false;
    double progress_step = 1.0 / (double)led_delta;
    uint16_t led_edge_bias = led_delta * progress;
    double from_low = progress_step * led_edge_bias;
    double from_high = progress_step * (led_edge_bias + 1);
    double edge_brightness = mapDouble(progress, from_low, from_high, 0.0, 255.0);
    edge_brightness = constrainDouble(edge_brightness, 0.0, 255.0);

    if (direction == 'R') {
        if (start_led < end_led) return false;

        int edge_led = start_led - led_edge_bias;
        for (int i = start_led; i > edge_led; i--)
            this->parent_controller->set_all_strips_pixel_color(i, r, g, b);

        this->parent_controller->set_all_strips_pixel_color(edge_led, dim(r, edge_brightness), dim(g, edge_brightness), dim(b, edge_brightness));
    } else if (direction == 'L') {
        if (start_led > end_led) return false;

        int edge_led = start_led + led_edge_bias;
        for (int i = start_led; i < edge_led; i++)
            this->parent_controller->set_all_strips_pixel_color(i, r, g, b);
    } else {
        return false;
    }
    return true;
}

double DirectionalFiller::mapDouble(double x, double in_min, double in_max, double out_min, double out_max) {
    return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
}

double DirectionalFiller::constrainDouble(double x, double a, double b) {
    if (x < a) return a;
    if (x > b) return b;
    return x;
}

uint8_t DirectionalFiller::dim(uint8_t color_value, double brightness) {
    return uint8_t((color_value * (brightness / 255.0)));
}
