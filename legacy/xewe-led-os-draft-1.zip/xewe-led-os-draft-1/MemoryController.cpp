#include "MemoryController.h"

MemoryController::MemoryController(int mem_start) : mem_start(mem_start) {}

byte* MemoryController::get_params(uint16_t size) {
    byte* params = new byte[size];
    for (uint16_t i = 0; i < size; i++) {
        params[i] = read_byte_eeprom(i);
    }
    return params;
}

void MemoryController::write_byte_eeprom(uint16_t address, uint8_t data) {
    if (MEM_CONTROLLER_DEBUG) {
        Serial.print("Saved to EEPROM at ");
        Serial.print(memStart + address);
        Serial.print(": ");
        Serial.println(data);
    }
    EEPROM.write(mem_start + address, data);
    EEPROM.commit();
}

byte MemoryController::read_byte_eeprom(uint16_t address) {
    uint8_t data = EEPROM.read(mem_start + address);
    if (MEM_CONTROLLER_DEBUG) {
        Serial.print("Got from EEPROM at ");
        Serial.print(memStart + address);
        Serial.print(": ");
        Serial.println(data);
    }
    return data;
}
