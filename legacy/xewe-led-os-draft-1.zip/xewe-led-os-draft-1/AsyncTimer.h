#ifndef ASYNCTIMER_H
#define ASYNCTIMER_H

#include <cstdint>
#include <Arduino.h>
#include <array>

template <typename T>
class AsyncTimer {

private:
    uint32_t start_time, end_time, delay;
    T start_val, end_val;
    bool done = false, initiated = false, debug = false;
    double progress;

public:
    // Constructor with delay only
    AsyncTimer(uint32_t delay, bool debug = false)
        : delay(delay), start_time(millis()), end_time(start_time + delay), start_val(T()), end_val(T()), debug(debug) {
        if (this->debug) {
            Serial.print("AsyncTimer initialized with delay: ");
            Serial.println(delay);
        }
    }

    // Constructor with delay, start_val, and end_val
    AsyncTimer(uint32_t delay, T start_val, T end_val, bool debug = false)
        : delay(delay), start_time(millis()), end_time(start_time + delay), start_val(start_val), end_val(end_val), debug(debug) {
        if (this->debug) {
            Serial.print("AsyncTimer initialized with delay: ");
            Serial.print(delay);
            Serial.print(", start_val: ");
            Serial.print(start_val);
            Serial.print(", end_val: ");
            Serial.println(end_val);
        }
    }

    // Method to get progress as float
    void calculate_progress(){
        this->progress = (millis() - start_time) / static_cast<double>(delay);
        if (progress > 1.0) {
            this->done = true;
            progress = 1;
        }
    }

    double get_progress() {
        this->calculate_progress();
        if (this->debug) {
            Serial.print("Progress: ");
            Serial.println(progress);
        }
        return progress;
    }

    T get_current_value() {
        T current_val = start_val + (end_val - start_val) * progress;
        if (this->debug) {
            Serial.print("Current value: ");
            Serial.println(current_val);
        }
        return current_val;
    }

    // Method to check if the timer is done
    bool is_done() {
        this->get_progress();
        if (this->debug) {
            Serial.print("Timer done: ");
            Serial.println(done);
        }
        return this->done;
    }

    // Method to check if the timer is active
    bool is_active() {
        this->get_progress();
        if (this->debug) {
            Serial.print("Timer active: ");
            Serial.println(!done);
        }
        return !this->done;
    }

    bool is_initiated() {
        if (this->debug) {
            Serial.print("Timer initiated: ");
            Serial.println(initiated);
        }
        return this->initiated;
    }

    bool is_not_initiated() {
        if (this->debug) {
            Serial.print("Timer not initiated: ");
            Serial.println(!this->initiated);
        }
        return !this->initiated;
    }

    void initiate() {
        this->initiated = true;
        if (this->debug) {
            Serial.println("Timer initiated");
        }
    }

    // Method to reset the timer
    void reset() {
        this->start_time = millis();
        this->end_time = this->start_time + this->delay;
        this->done = false;
        this->initiated = false;
        if (this->debug) {
            Serial.println("Timer reset");
        }
    }

    // Method to reset the timer with new parameters
    void reset(uint32_t new_delay) {
        this->delay = new_delay;
        reset();
        if (this->debug) {
            Serial.print("with new delay: ");
            Serial.println(new_delay);
        }
    }

    // Method to reset the timer with new parameters
    void reset(uint32_t new_delay, T new_start_val, T new_end_val) {
        this->delay = new_delay;
        this->start_val = new_start_val;
        this->end_val = new_end_val;
        reset();
        if (this->debug) {
            Serial.print("with new delay: ");
            Serial.print(new_delay);
            Serial.print(", new start_val: ");
            Serial.print(new_start_val);
            Serial.print(", new end_val: ");
            Serial.println(new_end_val);
        }
    }
};
#endif // ASYNCTIMER_H
