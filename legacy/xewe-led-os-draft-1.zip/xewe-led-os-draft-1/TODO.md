- add feature that when color is set to white, then perlin noise mode automatically switches to solid color
- add dimming into the directional fill function (i have it developed)

 // Demos
    // void demo_left_side(uint16_t fill_time) {

    //     left_side_fill_timer
    //     while (!left_side_complete)
    //         fill_left_from_center(255, 0, 0, fill_time);
    //     set_black_delayed(fill_time / 2);

    //     reset_left_side_vars();
    //     while (!left_side_complete)
    //         fill_left_from_center(0, 255, 0, fill_time);
    //     set_black_delayed(fill_time / 2);

    //     reset_left_side_vars();
    //     while (!left_side_complete)
    //         fill_left_from_center(0, 0, 255, fill_time);
    //     set_black_delayed(fill_time / 2);

    //     reset_left_side_vars();
    //     while (!left_side_complete)
    //         fill_left_from_edge(255, 0, 0, fill_time);
    //     set_black_delayed(fill_time / 2);

    //     reset_left_side_vars();
    //     while (!left_side_complete)
    //         fill_left_from_edge(0, 255, 0, fill_time);
    //     set_black_delayed(fill_time / 2);

    //     reset_left_side_vars();
    //     while (!left_side_complete)
    //         fill_left_from_edge(0, 0, 255, fill_time);
    //     set_black_delayed(fill_time / 2);
    // }

    // void demo_right_side(uint16_t fill_time) {
    //     reset_right_side_vars();
    //     while (!right_side_complete)
    //         fill_right_from_center(255, 0, 0, fill_time);
    //     set_black_delayed(fill_time / 2);

    //     reset_right_side_vars();
    //     while (!right_side_complete)
    //         fill_right_from_center(0, 255, 0, fill_time);
    //     set_black_delayed(fill_time / 2);

    //     reset_right_side_vars();
    //     while (!right_side_complete)
    //         fill_right_from_center(0, 0, 255, fill_time);
    //     set_black_delayed(fill_time / 2);

    //     reset_right_side_vars();
    //     while (!right_side_complete)
    //         fill_right_from_edge(255, 0, 0, fill_time);
    //     set_black_delayed(fill_time / 2);

    //     reset_right_side_vars();
    //     while (!right_side_complete)
    //         fill_right_from_edge(0, 255, 0, fill_time);
    //     set_black_delayed(fill_time / 2);

    //     reset_right_side_vars();
    //     while (!right_side_complete)
    //         fill_right_from_edge(0, 0, 255, fill_time);
    //     set_black_delayed(fill_time / 2);
    // }

    // void demo_edges(uint16_t fill_time) {
    //     reset_both_side_vars();
    //     while (!(left_side_complete && right_side_complete))
    //         fill_from_edges(255, 0, 0, fill_time);
    //     set_black_delayed(fill_time / 2);

    //     reset_both_side_vars();
    //     while (!(left_side_complete && right_side_complete))
    //         fill_from_edges(0, 255, 0, fill_time);
    //     set_black_delayed(fill_time / 2);

    //     reset_both_side_vars();
    //     while (!(left_side_complete && right_side_complete))
    //         fill_from_edges(0, 0, 255, fill_time);
    //     set_black_delayed(fill_time / 2);
    // }

    // void demo_center(uint16_t fill_time) {
    //     left_side_complete = false;
    //     right_side_complete = false;
    //     while (!left_side_complete && !right_side_complete)
    //         fill_from_center(255, 0, 0, fill_time);
    //     set_black_delayed(fill_time / 2);

    //     left_side_complete = false;
    //     right_side_complete = false;
    //     while (!left_side_complete && !right_side_complete)
    //         fill_from_center(0, 255, 0, fill_time);
    //     set_black_delayed(fill_time / 2);

    //     left_side_complete = false;
    //     right_side_complete = false;
    //     while (!left_side_complete && !right_side_complete)
    //         fill_from_center(0, 0, 255, fill_time);
    //     set_black_delayed(fill_time / 2);
    // }