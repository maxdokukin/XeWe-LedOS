#include "LedController.h"

LedController::LedController(Adafruit_NeoPixel* strip, uint16_t num_led, uint16_t memory_start_address)
    : led_strip(strip), num_led(num_led), num_led_strip(num_led), num_led_side(num_led / 2) {
    led_strip->begin();
    frame_timer = new AsyncTimer<uint16_t>(1000 / FPS);
    brightness_change_timer = new AsyncTimer<uint8_t>(0);

    for (int i = 0; i < 3; i++) rgb[i] = 0;

    EEPROM.begin(4096);
    memory = new MemoryController(memory_start_address);
    memory_init();

    perlin_fade = new PerlinFade(led_strip, num_led, get_hue(0, 65535), 10000, 10, 100, 255, 245, 255);
    left_side = new SolidColor(this, 0, this->num_led_side);
    right_side = new SolidColor(this, this->num_led_side, this->num_led_strip);
}

void LedController::frame() {
    if (frame_timer->is_done()) {
        frame_timer->reset();
        if (state == ON) {
            switch (mode) {
                case SOLID_COLOR:
                    left_side->frame();
                    right_side->frame();
                    led_strip->show();
                    break;
                case PERLIN:
                    perlin_fade->frame();
                    led_strip->show();
                    break;
            }
        }
        update_brightness();
    }
}

void LedController::enable_zigzag_mode() {
    is_zigzag_config = true;
    num_led_strip = num_led / 2;
    num_led_side = num_led / 4;
}

// template <typename T>
// void LedController::set_hue(T h, uint16_t low, uint16_t high) {
//     hue = map_to_byte(h, low, high);
//     if (LED_CONTROLLER_DEBUG) {
//         Serial.print("set_hue : ");
//         Serial.println(h);
//         Serial.print("set_hue mapped: ");
//         Serial.println(hue);
//     }
//     hue_updated = true;
//     update_color_from_hsv();
// }

// template <typename T>
// void LedController::set_sat(T s, uint16_t low, uint16_t high) {
//     sat = map_to_byte(s, low, high);
//     if (LED_CONTROLLER_DEBUG) {
//         Serial.print("set_sat : ");
//         Serial.println(s);
//         Serial.print("set_sat mapped: ");
//         Serial.println(sat);
//     }
//     sat_updated = true;
//     update_color_from_hsv();
// }

// template <typename T>
// void LedController::set_brightness(T br, T low, T high) {
//     if (LED_CONTROLLER_DEBUG) {
//         Serial.print("set_brightness : ");
//         Serial.println(br);
//         Serial.print("set_brightness mapped : ");
//         Serial.println(map_to_byte(br, low, high));
//     }
//     set_target_brightness(map_to_byte(br, low, high));
// }

void LedController::set_rgb(uint8_t* new_rgb_array) {
    if (LED_CONTROLLER_DEBUG) {
        Serial.println("set_rgb : ");
        Serial.print("R ");
        Serial.println(new_rgb[0]);
        Serial.print("G ");
        Serial.println(new_rgb[1]);
        Serial.print("B ");
        Serial.println(new_rgb[2]);
    }
    update_color_from_rgb(new_rgb_array);
}

void LedController::set_rgb(long new_rgb) {
    uint8_t new_rgb_array[3];
    new_rgb_array[0] = ((new_rgb >> 16) & 0xFF);
    new_rgb_array[1] = ((new_rgb >> 8) & 0xFF);
    new_rgb_array[2] = (new_rgb & 0xFF);

    if (LED_CONTROLLER_DEBUG) {
        Serial.println("set_rgb : ");
        Serial.print("R ");
        Serial.println(new_rgb_array[0]);
        Serial.print("G ");
        Serial.println(new_rgb_array[1]);
        Serial.print("B ");
        Serial.println(new_rgb_array[2]);
    }
    update_color_from_rgb(new_rgb_array);
}

void LedController::set_mode(lights_mode m) {
    if (LED_CONTROLLER_DEBUG) {
        Serial.print("set_mode : ");
        Serial.println(m);
    }
    mode = m;
    memory->writeByteEEPROM(MODE_ADDRESS, static_cast<uint8_t>(mode));
}

void LedController::set_state(uint8_t s) {
    if (s)
        turn_on();
    else
        turn_off();
}

void LedController::turn_on() {
    if (state == ON)
        return;

    if (LED_CONTROLLER_DEBUG) {
        Serial.println("State set to ON");
    }

    memory->writeByteEEPROM(STATE_ADDRESS, 1);
    state = ON;
    set_target_brightness(memory->readByteEEPROM(BRIGHTNESS_ADDRESS));
}

void LedController::turn_off() {
    if (state == OFF)
        return;

    if (LED_CONTROLLER_DEBUG) {
        Serial.println("State set to OFF");
    }

    memory->writeByteEEPROM(STATE_ADDRESS, 0);
    state = OFF;
    set_target_brightness(0);
}

float LedController::get_hue(uint16_t low, uint16_t high) {
    if (LED_CONTROLLER_DEBUG) {
        Serial.print("get_hue : ");
        Serial.println(map(hue, 0, 255, low, high));
    }
    return map(hue, 0, 255, low, high);
}

float LedController::get_sat(uint16_t low, uint16_t high) {
    if (LED_CONTROLLER_DEBUG) {
        Serial.print("get_sat : ");
        Serial.println(map(sat, 0, 255, low, high));
    }
    return map(sat, 0, 255, low, high);
}

int LedController::get_brightness(uint16_t low, uint16_t high) {
    if (LED_CONTROLLER_DEBUG) {
        Serial.print("get_brightness : ");
        Serial.println(map(brightness, 0, 255, low, high));
    }
    return map(brightness, 0, 255, low, high);
}

int LedController::get_target_brightness(uint16_t low, uint16_t high) {
    if (LED_CONTROLLER_DEBUG) {
        Serial.print("get_target_brightness : ");
        Serial.println(map(memory->readByteEEPROM(BRIGHTNESS_ADDRESS), 0, 255, low, high));
    }
    return map(memory->readByteEEPROM(BRIGHTNESS_ADDRESS), 0, 255, low, high);
}

uint8_t LedController::get_state() {
    if (LED_CONTROLLER_DEBUG) {
        Serial.print("get_state : ");
        Serial.println(static_cast<uint8_t>(memory->readByteEEPROM(STATE_ADDRESS)));
    }
    return static_cast<uint8_t>(memory->readByteEEPROM(STATE_ADDRESS));
}

uint8_t LedController::get_mode() {
    if (LED_CONTROLLER_DEBUG) {
        Serial.print("get_mode : ");
        Serial.println(static_cast<lights_mode>(memory->readByteEEPROM(MODE_ADDRESS)));
    }
    return static_cast<uint8_t>(memory->readByteEEPROM(MODE_ADDRESS));
}

uint8_t LedController::get_r(uint16_t low, uint16_t high) {
    if (LED_CONTROLLER_DEBUG) {
        Serial.print("get_r : ");
        Serial.println(map(memory->readByteEEPROM(R_ADDRESS), 0, 255, low, high));
    }
    return map(memory->readByteEEPROM(R_ADDRESS), 0, 255, low, high);
}

uint8_t LedController::get_g(uint16_t low, uint16_t high) {
    if (LED_CONTROLLER_DEBUG) {
        Serial.print("get_g : ");
        Serial.println(map(memory->readByteEEPROM(G_ADDRESS), 0, 255, low, high));
    }
    return map(memory->readByteEEPROM(G_ADDRESS), 0, 255, low, high);
}

uint8_t LedController::get_b(uint16_t low, uint16_t high) {
    if (LED_CONTROLLER_DEBUG) {
        Serial.print("get_b : ");
        Serial.println(map(memory->readByteEEPROM(B_ADDRESS), 0, 255, low, high));
    }
    return map(memory->readByteEEPROM(B_ADDRESS), 0, 255, low, high);
}

void LedController::fill_all(uint8_t r, uint8_t g, uint8_t b) {
    for (int i = 0; i < num_led; i++) {
        set_all_strips_pixel_color(i, r, g, b);
    }
    led_strip->show();
}

void LedController::display_strip_center() {
    for (int i = 0; i < num_led_side; i++)
        led_strip->setPixelColor(i, 255, 255, 255);

    for (int i = num_led_side; i < num_led_strip; i++)
        led_strip->setPixelColor(i, 255, 0, 0);

    if (is_zigzag_config) {
        for (int i = num_led_strip; i < num_led_strip + num_led_side; i++)
            led_strip->setPixelColor(i, 0, 255, 0);

        for (int i = num_led_strip + num_led_side; i < num_led; i++)
            led_strip->setPixelColor(i, 0, 0, 255);
    }
    led_strip->show();
}

void LedController::demo() {
    this->display_strip_center();
    this->set_black_delayed(1000);

    this->fill_all(255, 0, 0);
    this->set_black_delayed(1000);
    this->fill_all(0, 255, 0);
    this->set_black_delayed(1000);
    this->fill_all(0, 0, 255);
    this->set_black_delayed(1000);

    this->set_rgb(0x0ff0000);
    unsigned start = millis();
    while (millis() - start < 2000)
        this->frame();

    this->set_rgb(0x00ff00);
    start = millis();
    while (millis() - start < 2000)
        this->frame();

    this->set_rgb(0x0000ff);
    start = millis();
    while (millis() - start < 2000)
        this->frame();

    start = millis();
    while (millis() - start < 2000)
        this->fill_left_from_center(255, 0, 0, 1000);
}

void LedController::fill_left_from_center(byte rgb[3], uint16_t fill_time) {
    left_side->fill_in_R_to_L(rgb, fill_time);
}

void LedController::fill_left_from_edge(byte rgb[3], uint16_t fill_time) {
    left_side->fill_in_L_to_R(rgb, fill_time);
}

void LedController::fill_right_from_center(byte rgb[3], uint16_t fill_time) {
    right_side->fill_in_L_to_R(rgb, fill_time);
}

void LedController::fill_right_from_edge(byte rgb[3], uint16_t fill_time) {
    right_side->fill_in_R_to_L(rgb, fill_time);
}


// Memory
void LedController::memory_init() {
        uint8_t* params = memory->getParams(6);

    if (LED_CONTROLLER_DEBUG) {
        Serial.println("eeprom_init : ");
        Serial.print("P0 ");
        Serial.println(params[0]);
        Serial.print("P1 ");
        Serial.println(params[1]);
        Serial.print("P2 ");
        Serial.println(params[2]);
        Serial.print("P3 ");
        Serial.println(params[3]);
        Serial.print("P4 ");
        Serial.println(params[4]);
    }

    set_rgb(params);
    set_brightness<uint8_t>(params[BRIGHTNESS_ADDRESS], 0, 255);
    set_mode(static_cast<lights_mode>(params[MODE_ADDRESS]));
    set_state(params[STATE_ADDRESS]);
}

void LedController::save_rgb_to_mem(uint8_t* new_rgb) {
    memory->writeByteEEPROM(R_ADDRESS, new_rgb[0]);
    memory->writeByteEEPROM(G_ADDRESS, new_rgb[1]);
    memory->writeByteEEPROM(B_ADDRESS, new_rgb[2]);
}

void LedController::new_color_event(uint8_t* new_rgb) {
    if (LED_CONTROLLER_DEBUG) {
        printf("Entering new_color_event with new_rgb: %d, %d, %d\n", new_rgb[0], new_rgb[1], new_rgb[2]);
    }

    switch (mode) {
        case SOLID_COLOR:{
            if (LED_CONTROLLER_DEBUG) {
                printf("Mode: SOLID_COLOR, transitioning to SOLID_COLOR_TRANSITION\n");
            }
            mode = SOLID_COLOR_TRANSITION;
            std::array<uint8_t, 3> new_rgb_array = {new_rgb[0], new_rgb[1], new_rgb[2]};
            color_change_timer->reset(SOLID_COLOR_TRANSITION_TIME, rgb, new_rgb_array.data());
            if (LED_CONTROLLER_DEBUG) {
                printf("color_change_timer reset with new_rgb_array: %d, %d, %d\n", new_rgb_array[0], new_rgb_array[1], new_rgb_array[2]);
            }
            return;}
        case SOLID_COLOR_TRANSITION:{
            if (LED_CONTROLLER_DEBUG) {
                printf("Mode: SOLID_COLOR_TRANSITION, ignoring new color\n");
            }
            return;}
        case PERLIN:{
            if (LED_CONTROLLER_DEBUG) {
                printf("Mode: PERLIN, setting new hue\n");
            }
            perlin_fade->setNewHue(map(hue, 0, 360, 0, 65535));
            if (LED_CONTROLLER_DEBUG) {
                printf("perlin_fade new hue set with hue: %d\n", hue);
            }
            return;}
    }
}

void LedController::update_color_from_hsv() {
    if (hue_updated && sat_updated) {
        uint8_t new_rgb[3];
        HSV2RGB(map(hue, 0, 255, 0, 360), map(sat, 0, 255, 0, 100), map(val, 0, 255, 0, 100), new_rgb);
        hue_updated = sat_updated = false;

        save_rgb_to_mem(new_rgb);
        new_color_event(new_rgb);
    }
}

void LedController::update_color_from_rgb(uint8_t* new_rgb) {
    if (rgb[0] == new_rgb[0] && rgb[1] == new_rgb[1] && rgb[2] == new_rgb[2])
        return;
    float hsv[3];
    RGB2HSV(new_rgb, hsv);
    hue = hsv[0] * 255;
    sat = 255;
    val = 255;

    if (LED_CONTROLLER_DEBUG) {
        Serial.println("update_color_from_rgb : ");
        Serial.print("H : ");
        Serial.println(hsv[0]);
        Serial.print("S : ");
        Serial.println(hsv[1]);
        Serial.print("V : ");
        Serial.println(hsv[2]);
    }

    save_rgb_to_mem(new_rgb);
    new_color_event(new_rgb);
}

void LedController::set_target_brightness(uint8_t target_brightness) {
    if (brightness_change_timer->is_done()) {
        brightness_change_timer->reset(BRIGHTNESS_TRANSITION_TIME, brightness, target_brightness);
        if (target_brightness) {
            memory->writeByteEEPROM(BRIGHTNESS_ADDRESS, target_brightness);
        }
    }
}

void LedController::update_brightness() {
    if (brightness_change_timer->is_active())
        led_strip->setBrightness(brightness_change_timer->get_current_value());
}

uint8_t LedController::dim(uint8_t color_value, double brightness) {
    return uint8_t((color_value * (brightness / 255.0)));
}

void LedController::set_all_strips_pixel_color(uint16_t i, uint8_t r, uint8_t g, uint8_t b) {
    led_strip->setPixelColor(i, r, g, b);
    if (is_zigzag_config) {
        led_strip->setPixelColor(num_led - i - 1, r, g, b);
    }
}

void LedController::set_black() {
    fill_all(0, 0, 0);
}

void LedController::set_black_delayed(uint16_t delay_time) {
    delay(delay_time);
    fill_all(0, 0, 0);
    delay(delay_time);
}
