#ifndef DIRECTIONALFILLER_H
#define DIRECTIONALFILLER_H

#include <cstdint>
#include "AsyncTimer.h"
#include "LedController.h"

class DirectionalFiller {
    uint8_t r, g, b;
    int start_led, end_led;
    char direction;
    AsyncTimer<uint32_t>* timer;
    LedController *parent_controller;

public:
    DirectionalFiller(LedController *parent_controller);

    void frame();
    bool is_done();
    void set_target(uint8_t r, uint8_t g, uint8_t b, int start_led, int end_led, uint16_t delay, char direction);

private:
    bool fill_directional(double progress);
    double mapDouble(double x, double in_min, double in_max, double out_min, double out_max);
    double constrainDouble(double x, double a, double b);
    uint8_t dim(uint8_t color_value, double brightness);
};

#endif // DIRECTIONALFILLER_H
