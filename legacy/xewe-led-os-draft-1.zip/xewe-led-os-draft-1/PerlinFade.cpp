#include "PerlinFade.h"

// Constructor implementation
PerlinFade(
    Adafruit_NeoPixel *led_strip,
    uint16_t led_num,
    uint16_t hue_start,
    uint16_t hue_gap,
    byte fire_step,
    byte min_bright,
    byte max_bright,
    byte min_sat,
    byte max_sat
)
    : led_strip(led_strip), led_num(led_num), hue_start(led_num), hue_gap(hue_gap), fire_step(fire_step),
      min_bright(min_bright), max_bright(max_bright), min_sat(min_sat), max_sat(max_sat),
      half_hue_gap(hue_gap / 2), adjusted_hue_gap(adjust_hue_gap()), adjusted_hue_gap_half(adjusted_hue_gap / 2)
{
}

// Method to retrieve the current frame
void PerlinFade::frame() {
    if (millis() - last_frame < 10)
        return;

    hue_change();

    for (int i = 0; i < led_num; i++) {
        // led_strip->setPixelColor(i, get_fire_color(inoise8(i * fire_step, counter)));
    }

    counter += 5;
    last_frame = millis();
}

// Method to handle hue change
void PerlinFade::hue_change() {
    if (hue_changing) {
        uint16_t delta = millis() - hue_change_start_time;

        if (delta <= HUE_CHANGE_TIME) {
            hue_start = hue_old + (hue_target - hue_old) * (delta / (float)HUE_CHANGE_TIME);
        } else {
            if (PERLIN_DEBUG) {
                Serial.print("hue_change : done. ");
                Serial.println(hue_target);
                Serial.print("time : ");
                Serial.println(millis());
            }

            hue_start = hue_target;
            hue_changing = false;
            hue_change_start_time = 0;
            adjusted_hue_gap = adjust_hue_gap();
            adjusted_hue_gap_half = adjusted_hue_gap / 2;
        }
    }
}

// Method to set a new hue target
void PerlinFade::set_new_hue(uint16_t ht) {
    hue_target = ht;
    hue_old = hue_start;
    hue_change_start_time = millis();
    hue_changing = true;

    if (PERLIN_DEBUG) {
        Serial.print("set_new_hue : ");
        Serial.println(ht);
        Serial.print("hue_old : ");
        Serial.println(hue_old);
        Serial.print("hue_change_start_time : ");
        Serial.println(hue_change_start_time);
        Serial.print("millis : ");
        Serial.println(millis());
        Serial.print("hue_changing : ");
        Serial.println(hue_changing);
    }
}

// Method to get the fire color
long PerlinFade::get_fire_color(int val) {
    return led_strip->ColorHSV(
        hue_start - adjusted_hue_gap_half + map(val, 0, 255, 0, adjusted_hue_gap),
        constrain(map(val, 0, 255, max_sat, min_sat), 0, 255),
        constrain(map(val, 0, 255, min_bright, max_bright), 0, 255)
    );
}

// Private helper method to adjust the hue gap
uint16_t PerlinFade::adjust_hue_gap() {
    if (hue_start > 55000 || hue_start < 10000) {
        return hue_gap * 0.2;
    } else {
        return hue_gap;
    }
}
