#ifndef MEMORYCONTROLLER_H
#define MEMORYCONTROLLER_H

#include <EEPROM.h>
#include <Arduino.h>

#define MEMORYCONTROLLER_DEBUG true

class MemoryController {
  private:
    int mem_start;

  public:
    MemoryController(int mem_start);

    uint8_t* get_params(uint16_t size);

    void write_byte_eeprom(int address, byte data);

    byte read_byte_eeprom(int address);
};

#endif // MEMORYCONTROLLER_H
