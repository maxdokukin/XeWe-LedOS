#ifndef SOLID_COLOR_H
#define SOLID_COLOR_H

#include "AsyncTimerArray.h"
#include "DirectionalFiller.h"
#include "LedController.h"

enum solid_color_state {
    STILL,
    CHANGING_COLOR,
    FILLING,
};

class SolidColor {
private:
    AsyncTimerArray* color_change_timer;
    DirectionalFiller* filler_controller;
    LedController* parent_controller;

    byte current_rgb[3];
    uint16_t start_led;
    uint16_t end_led;

    solid_color_state state;

    void changing_color_frame();
    void filling_color_frame();

public:
    SolidColor(LedController* parent_controller, uint16_t start_led, uint16_t end_led);

    void set_color(byte new_rgb[3]);
    void set_color_gradually(byte new_rgb[3], uint16_t fill_time);
    void fill_in_L_to_R(byte rgb[3], uint16_t fill_time);
    void fill_in_R_to_L(byte rgb[3], uint16_t fill_time);

    void frame();
};

#endif // SOLID_COLOR_H
