#ifndef PERLIN_FADE_H
#define PERLIN_FADE_H

#include <Adafruit_NeoPixel.h>
#include <Arduino.h>

#define HUE_CHANGE_TIME 900
#define PERLIN_DEBUG false

class PerlinFade {
private:
    // Frame drawing
    uint32_t last_frame = 0;
    uint32_t counter = 0;

    // LEDs
    Adafruit_NeoPixel *led_strip;
    uint16_t led_num;

    // Colors
    uint16_t hue_start;
    uint16_t hue_gap;
    uint16_t adjusted_hue_gap;
    uint16_t adjusted_hue_gap_half;
    uint16_t half_hue_gap;
    byte fire_step;
    byte min_bright;
    byte max_bright;
    byte min_sat;
    byte max_sat;

    // Smooth hue change
    bool hue_changing = false;
    uint16_t hue_old;
    uint16_t hue_target;
    uint32_t hue_change_start_time;

    // Private helper methods
    uint16_t adjust_hue_gap();

public:
    // Constructor
    PerlinFade(
        Adafruit_NeoPixel *led_strip,
        uint16_t led_num,
        uint16_t hue_start,
        uint16_t hue_gap,
        byte fire_step,
        byte min_bright,
        byte max_bright,
        byte min_sat,
        byte max_sat
    );

    // Public methods
    void frame();
    void hue_change();
    void set_new_hue(uint16_t ht);
    long get_fire_color(int val);
};

#endif // PERLIN_FADE_H
