#include <Arduino.h>
#include <Adafruit_NeoPixel.h>
#include <cstdint>
#include "LedController.h"

// Define the pin for the NeoPixel strip
#define LED_PIN 2

// Define the number of LEDs in the strip
#define NUM_LEDS 20

// Create an instance of the Adafruit_NeoPixel class
Adafruit_NeoPixel strip(NUM_LEDS, LED_PIN, NEO_GRB + NEO_KHZ800);

// Create an instance of the LedController class
LedController *ledController;

void setup() {
    // Initialize serial communication
    Serial.begin(115200);
    delay(1000);
    // Announce the start of the test
    Serial.println("================================");
    Serial.println("================================");
    Serial.println("================================");
    Serial.println("Starting LED Controller tests...");

    ledController = new LedController(&strip, NUM_LEDS, 0);
    ledController->set_mode(SOLID_COLOR);
    ledController->enable_zigzag_mode();
    ledController->turn_on();
    ledController->set_brightness(255, 0, 255);
    // let it boot
    unsigned long start = millis();
    while (millis() - start < 1000)
        ledController->frame();

}

void loop() {
   // Test setting RGB color directly
    ledController->demo(); // sync function. will hold the code!


    //    // Test setting RGB color directly
    // Serial.println("Setting RGB color to Green...");
    // ledController->set_rgb(0x00ff00);
    // start = millis();
    // while (millis() - start < 1000) {
    //     ledController->frame();
    // }

    // Serial.println("Setting RGB color to Blue...");
    // uint8_t blue[3] = {0, 255, 0};
    // ledController->set_rgb(blue);
    // start = millis();
    // while (millis() - start < 1000) {
    //     ledController->frame();
    // }


/*
    Serial.println("Setting RGB color to Green...");
    uint8_t green[3] = {0, 255, 0};
    ledController.set_rgb(green);
    {
        unsigned long start = millis();
        while (millis() - start < 1000) {
            ledController.frame();
        }
    }

    Serial.println("Setting RGB color to Blue...");
    uint8_t blue[3] = {0, 0, 255};
    ledController.set_rgb(blue);
    {
        unsigned long start = millis();
        while (millis() - start < 1000) {
            ledController.frame();
        }
    }

    // Test setting RGB color with long integer
    Serial.println("Setting RGB color to Yellow using long integer...");
    long yellow = 0xFFFF00;
    ledController.set_rgb(yellow);
    {
        unsigned long start = millis();
        while (millis() - start < 1000) {
            ledController.frame();
        }
    }

    // Test setting brightness
    Serial.println("Setting brightness to 128...");
    ledController.set_brightness(128, 0, 255);
    {
        unsigned long start = millis();
        while (millis() - start < 1000) {
            ledController.frame();
        }
    }

    Serial.println("Setting brightness to 64...");
    ledController.set_brightness(64, 0, 255);
    {
        unsigned long start = millis();
        while (millis() - start < 1000) {
            ledController.frame();
        }
    }

    // Test Perlin fade
    Serial.println("Switching to Perlin fade mode...");
    ledController.set_mode(PERLIN);
    {
        unsigned long start = millis();
        while (millis() - start < 5000) {
            ledController.frame();
        }
    }

    Serial.println("Running Perlin fade for 5 seconds...");
    for (int i = 0; i < 50; i++) {
        ledController.frame();
        {
            unsigned long start = millis();
            while (millis() - start < 100) {
                ledController.frame();
            }
        }
    }

    // Test turning off and on
    Serial.println("Turning off the LEDs...");
    ledController.turn_off();
    {
        unsigned long start = millis();
        while (millis() - start < 2000) {
            ledController.frame();
        }
    }

    Serial.println("Turning on the LEDs...");
    ledController.turn_on();
    {
        unsigned long start = millis();
        while (millis() - start < 2000) {
            ledController.frame();
        }
    }

    // End of tests
    Serial.println("LED Controller tests completed.");
    while (true) {
        // Stop the loop
    }*/
}
