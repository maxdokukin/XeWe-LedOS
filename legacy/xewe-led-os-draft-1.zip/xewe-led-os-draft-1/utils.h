#ifndef UTILS_H
#define UTILS_H

// Function declarations
short colCon(long hexValue, char color);
long getMixCol(long col1, long col2, float br);
void getMixCol(byte* col_1, byte* col_2, byte* col_mix, float progress);
long getBrCol(long col, float br);
float fract(float x);
float mix(float a, float b, float t);
float step(float e, float x);
float* RGB2HSV(byte* params, float* hsv);
void HSV2RGB(float h, float s, float v, byte* RGB);
template <typename T>
uint8_t dim(uint8_t color_value, double brightness);
double mapDouble(double x, double in_min, double in_max, double out_min, double out_max);
double constrainDouble(double x, double a, double b);

// Helper function to map values to the range [0, 255]
template <typename T>
uint8_t map_to_byte(T value, T in_min, T in_max) {
    return (uint8_t)((float)(value - in_min) / (in_max - in_min) * 255);
}

#endif // UTILS_H
