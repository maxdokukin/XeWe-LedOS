#ifndef LEDCONTROLLER_H
#define LEDCONTROLLER_H

#include <Arduino.h>
#include <Adafruit_NeoPixel.h>
#include <cstdint>

#include "utils.h"

#include "AsyncTimer.h"
#include "MemoryController.h"
#include "PerlinFade.h"
#include "SolidColor.h"

#define LED_CONTROLLER_DEBUG true
#define SOLID_COLOR_TRANSITION_TIME 900
#define BRIGHTNESS_TRANSITION_TIME 900
#define EDGE_FILL_TIME 500
#define FPS 100

// Memory addresses
#define R_ADDRESS_L 0
#define G_ADDRESS_L 1
#define B_ADDRESS_L 2
#define R_ADDRESS_R 3
#define G_ADDRESS_R 4
#define B_ADDRESS_R 5
#define BRIGHTNESS_ADDRESS 6
#define STATE_ADDRESS 7
#define MODE_ADDRESS 8

enum lights_mode {
    SOLID_COLOR,
    SOLID_COLOR_TRANSITION,
    PERLIN,
    FILLING
};

enum lights_state {
    OFF,
    ON
};

class LedController {
private:
    Adafruit_NeoPixel* led_strip;
    uint16_t num_led, num_led_strip, num_led_side;
    uint8_t brightness = 0, sat = 0, val = 0;
    uint8_t rgb[3];
    uint16_t hue = 0;
    bool hue_updated = false;
    bool sat_updated = false;

    bool is_zigzag_config = false;

    lights_mode mode = SOLID_COLOR;
    lights_state state = OFF;

    // Accessory classes
    MemoryController* memory;
    PerlinFade* perlin_fade;
    SolidColor* left_side;
    SolidColor* right_side;
    AsyncTimer<uint8_t>* frame_timer;
    AsyncTimer<uint8_t>* brightness_change_timer;

    void memory_init();
    void save_rgb_to_mem(uint8_t* new_rgb);

    void update_color_from_hsv();
    void update_color_from_rgb(uint8_t* new_rgb);
    void new_color_event(uint8_t* new_rgb);

    void set_target_brightness(uint8_t target_brightness);
    void update_brightness();

public:
    LedController(Adafruit_NeoPixel* strip, uint16_t num_led, uint16_t memory_start_address);
    ////////////////
    // Essentials //
    ////////////////
    // Flow control
    void frame();

    ///////////////////////////
    // Basic Visual Controls //
    ///////////////////////////
    // Color control
    template <typename T>
    void set_hue(T h, T low, T high);
    template <typename T>
    void set_sat(T s, T low, T high);
    template <typename T>
    void set_rgb(uint8_t* new_rgb);
    void set_rgb(long new_rgb);
    // Brightness control
    void set_brightness(T br, T low = 0, T high = 255);
    // Mode and state control
    void set_mode(lights_mode m);
    void set_state(uint8_t s);
    void turn_on();
    void turn_off();

    ///////////////////
    // Strip effects //
    ///////////////////
    // Directional fillers
    void fill_left_side_from_center(uint8_t rgb[3], uint16_t fill_time);
    void fill_left_side_from_edge(uint8_t rgb[3], uint16_t fill_time);
    void fill_right_side_from_center(uint8_t rgb[3], uint16_t fill_time);
    void fill_right_side_from_edge(uint8_t rgb[3], uint16_t fill_time);
    // Advanced visual setters
    void display_strip_center();
    void demo();

    /////////////
    // Getters //
    /////////////
    float get_hue(uint16_t low, uint16_t high);
    float get_sat(uint16_t low, uint16_t high);
    int get_brightness(uint16_t low, uint16_t high);
    int get_target_brightness(uint16_t low, uint16_t high);
    uint8_t get_state();
    uint8_t get_mode();
    uint8_t get_r(uint16_t low, uint16_t high);
    uint8_t get_g(uint16_t low, uint16_t high);
    uint8_t get_b(uint16_t low, uint16_t high);

    ////////////////////
    // Strip settings //
    ////////////////////
    void enable_zigzag_mode();
    void disable_zigzag_mode();
    void set_center_led(uint16_t center_led);


    ///////////////
    // Technical //
    ///////////////
    // this should be only accessed by other functional classes, but im not sure how to make it;
    //!!!not user friendly!!!//
    void set_all_strips_pixel_color(uint16_t i, uint8_t r, uint8_t g, uint8_t b);
};

#include "LedController.tpp"

#endif // LEDCONTROLLER_H
