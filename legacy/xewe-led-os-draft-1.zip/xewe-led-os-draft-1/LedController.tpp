#ifndef LEDCONTROLLER_TPP
#define LEDCONTROLLER_TPP

#include "LedController.h"

template <typename T>
void LedController::set_hue(T h, T low, T high) {
    hue = map_to_byte(h, low, high);
    if (LED_CONTROLLER_DEBUG) {
        Serial.print("set_hue : ");
        Serial.println(h);
        Serial.print("set_hue mapped: ");
        Serial.println(hue);
    }
    hue_updated = true;
    update_color_from_hsv();
}

template <typename T>
void LedController::set_sat(T s, T low, T high) {
    sat = map_to_byte(s, low, high);
    if (LED_CONTROLLER_DEBUG) {
        Serial.print("set_sat : ");
        Serial.println(s);
        Serial.print("set_sat mapped: ");
        Serial.println(sat);
    }
    sat_updated = true;
    update_color_from_hsv();
}

template <typename T>
void LedController::set_brightness(T br, T low, T high) {
    if (LED_CONTROLLER_DEBUG) {
        Serial.print("set_brightness : ");
        Serial.println(br);
        Serial.print("set_brightness mapped : ");
        Serial.println(map_to_byte(br, low, high));
    }
    set_target_brightness(map_to_byte(br, low, high));
}

#endif // LEDCONTROLLER_TPP
