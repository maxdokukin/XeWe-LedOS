#include "SolidColor.h"

// Constructor implementation
SolidColor::SolidColor(LedController* parent_controller, uint16_t start_led, uint16_t end_led)
    : parent_controller(parent_controller), start_led(start_led), end_led(end_led), state(STILL) {
    filler_controller = new DirectionalFiller(parent_controller);
    color_change_timer = new AsyncTimerArray(0);
}

// Method to set the color instantly
void SolidColor::set_color(byte new_rgb[3]) {
    for (uint16_t i = start_led; i < end_led; ++i) {
        parent_controller->set_all_strips_pixel_color(i, new_rgb[0], new_rgb[1], new_rgb[2]);
    }

    for (int i = 0; i < 3; ++i) {
        current_rgb[i] = new_rgb[i];
    }

    state = STILL;
}

// Method to set the color gradually
void SolidColor::set_color_gradually(byte new_rgb[3], uint16_t fill_time) {
    if (color_change_timer->is_not_initiated()) {
        color_change_timer->reset(fill_time, current_rgb, new_rgb);
        color_change_timer->initiate();
        state = CHANGING_COLOR;
    }
}

// Method to fill color from left to right
void SolidColor::fill_in_L_to_R(byte rgb[3], uint16_t fill_time) {
    if (filler_controller->is_done()) {
        filler_controller->set_target(rgb[0], rgb[1], rgb[2], start_led, end_led, fill_time, 'R');
        state = FILLING;
    }
}

// Method to fill color from right to left
void SolidColor::fill_in_R_to_L(byte rgb[3], uint16_t fill_time) {
    if (filler_controller->is_done()) {
        filler_controller->set_target(rgb[0], rgb[1], rgb[2], start_led, end_led, fill_time, 'L');
        state = FILLING;
    }
}

// Private method to handle gradual color change in each frame
void SolidColor::changing_color_frame() {
    if (color_change_timer->is_done()) {
        state = STILL;
    }

    byte* updated_rgb = color_change_timer->get_current_value();

    for (int i = 0; i < 3; ++i) {
        current_rgb[i] = updated_rgb[i];
    }

    for (uint16_t i = start_led; i < end_led; ++i) {
        parent_controller->set_all_strips_pixel_color(i, current_rgb[0], current_rgb[1], current_rgb[2]);
    }
}

// Private method to handle filling color in each frame
void SolidColor::filling_color_frame() {
    filler_controller->frame();

    if (filler_controller->is_done()) {
        state = STILL;
    }
}

// Public method to update the state in each frame
void SolidColor::frame() {
    switch (state) {
        case STILL:
            // Nothing to do
            break;
        case CHANGING_COLOR:
            changing_color_frame();
            break;
        case FILLING:
            filling_color_frame();
            break;
    }
}
