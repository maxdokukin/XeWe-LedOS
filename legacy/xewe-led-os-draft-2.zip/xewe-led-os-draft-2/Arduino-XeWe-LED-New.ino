#include <Adafruit_NeoPixel.h>
#define LED_PIN 2
#define NUM_LEDS 100
Adafruit_NeoPixel strip(NUM_LEDS, LED_PIN, NEO_GRB + NEO_KHZ800);

// confid add parameter num leds
#include "src/classes/LedController/LedController.h"
#include "src/functions/wifi.h"

LedController *controller;

void setup() {
    Serial.begin(115200);
    delay(1000);
    wifi_connect();
    controller = new LedController(&strip);
}

void loop() {
    controller->frame();
}
