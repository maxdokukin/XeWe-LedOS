#ifndef WIFI_H
#define WIFI_H

#if defined(ESP8266)
#include <ESP8266WiFi.h>
#elif defined(ESP32)
#include <WiFi.h>
#endif

// Wi-Fi network credentials
extern const char *ssid;
extern const char *password;

// Function to connect to Wi-Fi
void wifi_connect();

#endif  // WIFI_H
