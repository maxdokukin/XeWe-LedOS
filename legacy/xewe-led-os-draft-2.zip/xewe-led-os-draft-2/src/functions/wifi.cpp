#include "wifi.h"

// Define Wi-Fi network credentials
const char *ssid = "Max iPhone";
const char *password = "12121212";

// Function to connect to Wi-Fi
void wifi_connect() {
    WiFi.persistent(false);             // Disable persistent Wi-Fi parameters storage
    WiFi.mode(WIFI_STA);                // Set Wi-Fi mode to Station
    WiFi.setAutoReconnect(true);        // Enable auto-reconnect
    WiFi.begin(ssid, password);         // Start Wi-Fi connection with SSID and password
    Serial.println("WiFi connecting...");

    // Wait for connection
    while (!WiFi.isConnected()) {       // Wait for the connection to be established
        delay(100);
        Serial.print(".");
    }
    Serial.print("\n");

    // Check if IP is valid (not 0.0.0.0)
    if (WiFi.localIP().toString() == "0.0.0.0") {
        Serial.println("Connected, but IP is 0.0.0.0. Retrying...");

        // Optional: Retry connection or handle the issue here
        WiFi.disconnect();
        delay(1000);  // Small delay before retrying
        WiFi.begin(ssid, password); // Retry connection
    } else {
        Serial.printf("WiFi connected, IP: %s\n", WiFi.localIP().toString().c_str());
    }
}
