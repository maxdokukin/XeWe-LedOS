#include "config.h"

//ssid = "KGB Headquarters";
//wifi_password = "DecoratingLandsFace";
//wifi_server_url = "http://127.0.0.1:5000";
//wifi_device_id = "esp32-c3-unique-id";
//
//char* ssid;
//char* wifi_password;
//char* wifi_server_url;
//char* wifi_device_id;

//StrConfig str_config[] = {
//    {"ssid", "KGB Headquarters"},
//    {"wifi_password", "DecoratingLandsFace"},
//    {"wifi_server_url", "http://127.0.0.1:5000"},
//    {"wifi_device_id", "esp32-c3-unique-id"}
//};

Config config[] = {
    {"color_transition_delay", 900},//900 //add adaptive transition. if delta is slow, which will cause low fps, reduce delay
    {"led_controller_frame_delay", 10}, //100 fps
    {"brightness_transition_delay", 500},//1000 //add adaptive transition. if delta is slow, which will cause low fps, reduce delay
    {"memory_start_address", 0}, //1500 to save space for homekit
    {"num_led", 20},

    // New parameters for PerlinFade
    {"perlin_hue_transition_delay", 900}, // Default value for hue transition delay
    {"perlin_hue_gap", 10000}, // Default hue gap
    {"perlin_fire_step", 10}, // Default fire step
    {"perlin_min_bright", 100}, // Minimum brightness value
    {"perlin_max_bright", 255}, // Maximum brightness value
    {"perlin_min_sat", 245}, // Minimum saturation value
    {"perlin_max_sat", 255},
    {"webinterface_poll_interval", 3000},
    {"webinterface_heartbeat_interval", 60000}
};

int get_config_value(const char* key) {
    for (int i = 0; i < sizeof(config) / sizeof(config[0]); i++) {
        if (strcmp(config[i].parameter_key, key) == 0) {
            return config[i].value;
        }
    }
    return -1;
}

//const char* get_str_config_value(const char* key) {
//    for (int i = 0; i < sizeof(str_config) / sizeof(str_config[0]); i++) {
//        if (strcmp(str_config[i].parameter_key, key) == 0) {
//            return str_config[i].value;
//        }
//    }
//    return nullptr;  // Key not found
//}
