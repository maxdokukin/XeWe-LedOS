#ifndef CONFIG_H
#define CONFIG_H

#include <cstring>

struct Config {
    const char* parameter_key;
    unsigned int value;
};

extern Config config[];
int get_config_value(const char* key);

//struct StrConfig {
//    const char* parameter_key;
//    const char* value;
//};
//extern StrConfig str_config[];
//const char* get_str_config_value(const char* key);

#endif  // CONFIG_H
