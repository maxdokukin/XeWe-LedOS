#ifndef WEBINTERFACE_H
#define WEBINTERFACE_H

#include <Arduino.h>
#if defined(ESP8266)
#include <ESP8266WiFi.h>
#elif defined(ESP32)
#include <WiFi.h>
#endif
#include <HTTPClient.h>
#include "../../AsyncTimers/AsyncTimer.h"
#include <ArduinoJson.h>

class LedController;

class WebInterface {
public:
    WebInterface(LedController* controller);
    void frame();

private:
    void process_command(const char* command);
    void send_heartbeat();
    void poll();

    LedController* led_controller;
    AsyncTimer<uint8_t>* heartbeat_timer;
    AsyncTimer<uint8_t>* poll_timer;
};

#endif  // WEBINTERFACE_H
