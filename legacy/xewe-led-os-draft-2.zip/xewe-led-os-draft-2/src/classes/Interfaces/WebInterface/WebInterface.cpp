#include "WebInterface.h"
#include "../../LedController/LedController.h"

const char* wifi_server_url = "https://esp-web-server-460110950298.us-west1.run.app/get_data";
const char* wifi_device_id = "esp32-c3-unique-id";

WebInterface::WebInterface(LedController* controller)
    : led_controller(controller) {
    // Retrieve and print configuration values for heartbeat and poll intervals
    int heartbeat_interval = get_config_value("webinterface_heartbeat_interval");
    int poll_interval = get_config_value("webinterface_poll_interval");

    Serial.println("Initializing WebInterface...");
    Serial.print("Heartbeat interval set to: ");
    Serial.println(heartbeat_interval);
    Serial.print("Poll interval set to: ");
    Serial.println(poll_interval);

    // Set timers
    heartbeat_timer = new AsyncTimer<uint8_t>(heartbeat_interval);
    poll_timer = new AsyncTimer<uint8_t>(poll_interval);

    // Start initial heartbeat
    send_heartbeat();
}

void WebInterface::frame() {
    //Serial.println("Entering WebInterface::frame()...");

    // Check and reset heartbeat timer
    if (heartbeat_timer->is_done()) {
        Serial.println("Heartbeat timer expired, sending heartbeat...");
        heartbeat_timer->reset();
        send_heartbeat();
    }

    // Check and reset poll timer
    if (poll_timer->is_done()) {
        //Serial.println("Poll timer expired, polling for commands...");
        poll_timer->reset();
        poll();
    }
}

void WebInterface::send_heartbeat() {
    Serial.println("Entering WebInterface::send_heartbeat()...");

    if (WiFi.status() == WL_CONNECTED) {
        HTTPClient http;

        // Construct URL for heartbeat
        const char* server_url = wifi_server_url;
        char url[100];
        snprintf(url, sizeof(url), "%s/esp_heartbeat", server_url);

        Serial.print("Heartbeat URL: ");
        Serial.println(url);

        // Start HTTP connection
        http.begin(url);
        http.addHeader("Content-Type", "application/json");

        // Create JSON data for device ID
        const char* device_id = wifi_device_id;
        char post_data[100];
        snprintf(post_data, sizeof(post_data), "{\"device_id\": \"%s\"}", device_id);

        Serial.print("Heartbeat JSON payload: ");
        Serial.println(post_data);

        // Send POST request
        int http_response_code = http.POST((uint8_t*)post_data, strlen(post_data));
        http.end();

        if (http_response_code > 0) {
            Serial.print("Heartbeat sent successfully, response code: ");
            Serial.println(http_response_code);
        } else {
            Serial.print("Failed to send heartbeat, response code: ");
            Serial.println(http_response_code);
        }
    } else {
        Serial.println("WiFi not connected, heartbeat not sent.");
    }
}


void WebInterface::poll() {
    Serial.println("Entering WebInterface::poll()...");

    if (WiFi.status() == WL_CONNECTED) {
        HTTPClient http;

        // URL to fetch data
        const char* url = "https://esp-web-server-460110950298.us-west1.run.app/get_data";

        Serial.print("Fetching data from URL: ");
        Serial.println(url);

        // Begin HTTP GET request
        http.begin(url);

        int http_response_code = http.GET();
        if (http_response_code == HTTP_CODE_OK) {
            // Get response as a String
            String response = http.getString();
            Serial.print("Received JSON response: ");
            Serial.println(response);

            // Allocate a buffer to parse JSON
            StaticJsonDocument<200> doc;

            // Parse the JSON response
            DeserializationError error = deserializeJson(doc, response);
            if (error) {
                Serial.print("JSON parsing failed: ");
                Serial.println(error.c_str());
                return;
            }

            // Extract values from JSON
            byte r = doc["r"];
            byte g = doc["g"];
            byte b = doc["b"];
            byte brightness = doc["brightness"];
            byte mode = doc["mode"];
            byte state = doc["state"];

            // Print extracted values
            Serial.println("Parsed Data:");
            Serial.print("Red: ");
            Serial.println(r);
            Serial.print("Green: ");
            Serial.println(g);
            Serial.print("Blue: ");
            Serial.println(b);
            Serial.print("Brightness: ");
            Serial.println(brightness);
            Serial.print("Mode: ");
            Serial.println(mode);
            Serial.print("State: ");
            Serial.println(state);

            led_controller->set_rgb(r, g, b);
            led_controller->set_brightness(brightness);
            led_controller->set_mode(mode ? 4 : 1);
            led_controller->set_state(state);

        } else {
            Serial.print("HTTP request failed, response code: ");
            Serial.println(http_response_code);
        }
        http.end();
    } else {
        Serial.println("WiFi not connected, unable to fetch data.");
    }
}


void WebInterface::process_command(const char* command) {
    Serial.println("Entering WebInterface::process_command()...");
    Serial.print("Processing command: ");
    Serial.println(command);

    // Further command processing can be added here as required
}
