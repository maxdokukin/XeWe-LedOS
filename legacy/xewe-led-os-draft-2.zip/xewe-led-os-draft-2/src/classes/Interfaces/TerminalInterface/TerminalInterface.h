#ifndef TERMINALINTERFACE_H
#define TERMINALINTERFACE_H

#include <Arduino.h>

class LedController;

class TerminalInterface {
public:
    TerminalInterface(LedController* controller);
    void frame();

private:
    void process_command(const String& command);
    LedController* led_controller;
};

#endif  // TERMINALINTERFACE_H
