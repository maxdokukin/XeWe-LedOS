#include "TerminalInterface.h"
#include "../../LedController/LedController.h"

TerminalInterface::TerminalInterface(LedController* controller)
    : led_controller(controller) {
}

void TerminalInterface::frame() {
    if (Serial.available()) {
        String received_line = Serial.readStringUntil('\n');
        received_line.trim();

        if (received_line.startsWith("$")) {
            process_command(received_line);
        } else {
            Serial.println("Command must start with '$'.");
        }
    }
}

void TerminalInterface::process_command(const String& command) {
    Serial.print("Processing command: ");
    Serial.println(command);

    int first_space = command.indexOf(' ');
    String command_name = (first_space != -1) ? command.substring(0, first_space) : command;
    String args = (first_space != -1) ? command.substring(first_space + 1) : "";

    if (command_name == "$set_mode") {
        int mode = args.toInt();
        led_controller->set_mode(static_cast<uint8_t>(mode));
        Serial.print("Set mode to: ");
        Serial.println(mode);

    } else if (command_name == "$set_rgb") {
        int r, g, b;
        sscanf(args.c_str(), "%d %d %d", &r, &g, &b);
        led_controller->set_rgb(r, g, b);

    } else if (command_name == "$set_hsv") {
        int hue, saturation, value;
        sscanf(args.c_str(), "%d %d %d", &hue, &saturation, &value);
        led_controller->set_hsv(hue, saturation, value);

    } else if (command_name == "$set_hue") {
        int hue = args.toInt();
        led_controller->set_hue(static_cast<uint8_t>(hue));
        Serial.print("Set hue to: ");
        Serial.println(hue);

    } else if (command_name == "$set_sat") {
        int saturation = args.toInt();
        led_controller->set_sat(static_cast<uint8_t>(saturation));
        Serial.print("Set saturation to: ");
        Serial.println(saturation);

    } else if (command_name == "$set_val") {
        int value = args.toInt();
        led_controller->set_val(static_cast<uint8_t>(value));
        Serial.print("Set value to: ");
        Serial.println(value);

    } else if (command_name == "$set_r") {
        int r = args.toInt();
        led_controller->set_r(static_cast<uint8_t>(r));
        Serial.print("Set red to: ");
        Serial.println(r);

    } else if (command_name == "$set_g") {
        int g = args.toInt();
        led_controller->set_g(static_cast<uint8_t>(g));
        Serial.print("Set green to: ");
        Serial.println(g);

    } else if (command_name == "$set_b") {
        int b = args.toInt();
        led_controller->set_b(static_cast<uint8_t>(b));
        Serial.print("Set blue to: ");
        Serial.println(b);

    } else if (command_name == "$set_brightness") {
        int brightness = args.toInt();
        led_controller->set_brightness(brightness);
        Serial.print("Set brightness to: ");
        Serial.println(brightness);

    } else if (command_name == "$turn_on") {
        led_controller->turn_on();

    } else if (command_name == "$turn_off") {
        led_controller->turn_off();

    } else {
        Serial.println("Unknown command.");
    }
}
