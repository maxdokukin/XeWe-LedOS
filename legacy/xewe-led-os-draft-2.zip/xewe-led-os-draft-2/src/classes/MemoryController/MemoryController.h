#ifndef MEMORY_CONTROLLER_H
#define MEMORY_CONTROLLER_H

#include <EEPROM.h>

class MemoryController {
private:
    uint16_t mem_start_addr;

    void write_byte_eeprom(uint16_t address, uint8_t data);
    uint8_t read_byte_eeprom(uint16_t address);

public:
    MemoryController(uint16_t mem_start_addr);

    void write_r(uint8_t value);
    uint8_t read_r();
    void write_g(uint8_t value);
    uint8_t read_g();
    void write_b(uint8_t value);
    uint8_t read_b();
    void write_rgb(uint8_t r, uint8_t g, uint8_t b);
    uint8_t* read_rgb();
    void write_brightness(uint8_t value);
    uint8_t read_brightness();
    void write_state(uint8_t value);
    uint8_t read_state();
    void write_mode(uint8_t value);
    uint8_t read_mode();
};

#endif  // MEMORY_CONTROLLER_H
