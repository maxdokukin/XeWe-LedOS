#include "MemoryController.h"

MemoryController::MemoryController(uint16_t mem_start_addr)
    : mem_start_addr(mem_start_addr) {
    EEPROM.begin(2048);
}

void MemoryController::write_byte_eeprom(uint16_t address, uint8_t data) {
    EEPROM.write(mem_start_addr + address, data);
    EEPROM.commit();
}

uint8_t MemoryController::read_byte_eeprom(uint16_t address) {
    return EEPROM.read(mem_start_addr + address);
}

void MemoryController::write_r(uint8_t value) {
    write_byte_eeprom(0, value);
}

uint8_t MemoryController::read_r() {
    return read_byte_eeprom(0);
}

void MemoryController::write_g(uint8_t value) {
    write_byte_eeprom(1, value);
}

uint8_t MemoryController::read_g() {
    return read_byte_eeprom(1);
}

void MemoryController::write_b(uint8_t value) {
    write_byte_eeprom(2, value);
}

uint8_t MemoryController::read_b() {
    return read_byte_eeprom(2);
}

void MemoryController::write_brightness(uint8_t value) {
    write_byte_eeprom(3, value);
}

uint8_t MemoryController::read_brightness() {
    return read_byte_eeprom(3);
}

void MemoryController::write_state(uint8_t value) {
    write_byte_eeprom(4, value);
}

uint8_t MemoryController::read_state() {
    return read_byte_eeprom(4);
}

void MemoryController::write_mode(uint8_t value) {
    write_byte_eeprom(5, value);
}

uint8_t MemoryController::read_mode() {
    return read_byte_eeprom(5);
}

void MemoryController::write_rgb(uint8_t r, uint8_t g, uint8_t b) {
    write_byte_eeprom(0, r);
    write_byte_eeprom(1, g);
    write_byte_eeprom(2, b);
}

uint8_t* MemoryController::read_rgb() {
    static uint8_t rgb[3];
    rgb[0] = read_byte_eeprom(0);
    rgb[1] = read_byte_eeprom(1);
    rgb[2] = read_byte_eeprom(2);
    return rgb;
}
