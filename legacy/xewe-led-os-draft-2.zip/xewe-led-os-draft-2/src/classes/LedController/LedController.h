#ifndef LEDCONTROLLER_H
#define LEDCONTROLLER_H

#include <Adafruit_NeoPixel.h>
#include "../AsyncTimers/AsyncTimer.h"
#include "../Interfaces/TerminalInterface/TerminalInterface.h"
#include "../Interfaces/WebInterface/WebInterface.h"
#include "../Brightness/Brightness.h"
#include "../LedModes/SolidColor/SolidColor.h"
#include "../LedModes/ChangingColor/ChangingColor.h"
#include "../LedModes/PerlinFade/PerlinFade.h"
#include "../MemoryController/MemoryController.h"

class LedController {
private:
    AsyncTimer<uint8_t>* frame_timer;       // Timer to manage frame updates

    TerminalInterface* terminal;
    WebInterface* web_interface;

    LedMode* led_mode;
    MemoryController* memory;
public:
    Adafruit_NeoPixel* led_strip;  // Pointer to the LED strip object
    uint16_t num_led;              // Number of LEDs in the strip

    Brightness* brightness;

    // Constructor
    LedController(Adafruit_NeoPixel* strip);

    // Main frame update function (called repeatedly in the loop)
    void frame();

    // Mode control
    void set_mode(uint8_t new_mode);

    // Color control
    void set_rgb(uint8_t r, uint8_t g, uint8_t b);
    void set_r(uint8_t r);
    void set_g(uint8_t g);
    void set_b(uint8_t b);
    void set_hsv(uint8_t hue, uint8_t saturation, uint8_t value);
    void set_hue(uint8_t hue);
    void set_sat(uint8_t saturation);
    void set_val(uint8_t value);

    // Brightness control
    void set_brightness(uint8_t new_brightness);

    // Power control
    void set_state(byte state);
    void turn_on();
    void turn_off();

    // Set pixels
    void fill_all(uint8_t r, uint8_t g, uint8_t b);
    void set_all_strips_pixel_color(uint16_t i, uint8_t r, uint8_t g, uint8_t b);
    void set_led_brightness(uint8_t brightness);
};

#endif  // LEDCONTROLLER_H
