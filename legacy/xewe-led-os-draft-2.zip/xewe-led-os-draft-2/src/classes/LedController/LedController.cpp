#include "../../config/config.h"

#include "LedController.h"

LedController::LedController(Adafruit_NeoPixel* strip)
    : led_strip(strip) {

    led_strip->begin();
    led_strip->setBrightness(255);
    num_led = get_config_value("num_led");

    // EEPROM Memory
    memory = new MemoryController(get_config_value("memory_start_address"));

    //    Communication
    terminal = new TerminalInterface(this);
    web_interface = new WebInterface(this);

    //    Functional classes
    frame_timer = new AsyncTimer<uint8_t>(get_config_value("led_controller_frame_delay"));
    // read from memory mode
    led_mode = new SolidColor(this, memory->read_r(), memory->read_g(), memory->read_b());
    LedMode::set_rgb(memory->read_r(), memory->read_g(), memory->read_b());
    LedMode::rgb_to_hsv();

    brightness = new Brightness(this, memory->read_state() ? memory->read_brightness() : 0);

    Serial.println("LedController: Constructor called");
}

void LedController::frame() {
    // Call the terminal frame method
    if(frame_timer->is_active())
        return;
    frame_timer->reset();

    terminal->frame();
    web_interface->frame();
    brightness->frame();
    led_mode->frame();

    // Switch statement for different LED modes
    switch (led_mode->get_mode_id()) {
        case 1:
            break;

        case 2:
            if (led_mode->is_done()){
                delete led_mode;
                led_mode = new SolidColor(this);
            }
            break;
        case 3:
            // Add logic for DIRECTIONAL_FILLER mode here
            Serial.println("Mode: DIRECTIONAL_FILLER");
            break;

        case 4:
            // Add logic for PERLIN mode here
//            Serial.println("Mode: PERLIN");
            break;

        default:
            Serial.println("Unknown mode");
            break;
    }
}


void LedController::set_mode(uint8_t new_mode) {
    Serial.printf("LedController: Function: set_mode, mode = %d\n", new_mode);
    if(new_mode == led_mode->get_mode_id()){
        Serial.printf("LedController: Mode already set\n");
        return;
    }

    delete led_mode;

    switch (new_mode) {
        case 1:
            led_mode = new SolidColor(this);
            break;
        case 2:
            break;
        case 3:
            break;
        case 4:
            led_mode = new PerlinFade(this);
            break;
        default:
            break;
    }
}

void LedController::set_rgb(uint8_t r, uint8_t g, uint8_t b) {
    Serial.printf("LedController: Function: set_rgb, R = %d, G = %d, B = %d\n", r, g, b);
    if (!led_mode || !led_mode->is_done()) {
        Serial.println("LedController: Still changing previous color or led_mode is null");
        return;
    }
    if (r == LedMode::get_r() && g == LedMode::get_g() && b == LedMode::get_b()) {
        Serial.println("LedController: Color already set");
        return;
    }
    delete led_mode;
    led_mode = new ChangingColor(this, LedMode::get_r(), LedMode::get_g(), LedMode::get_b(), r, g, b, get_config_value("color_transition_delay"));
    LedMode::set_rgb(r, g, b);
    LedMode::rgb_to_hsv();
    memory->write_rgb(r, g, b);
}

void LedController::set_r(uint8_t r) {
    Serial.printf("LedController: Function: set_r, R = %d\n", r);
    set_rgb(r, LedMode::get_g(), LedMode::get_b());
}

void LedController::set_g(uint8_t g) {
    Serial.printf("LedController: Function: set_g, G = %d\n", g);
    set_rgb(LedMode::get_r(), g, LedMode::get_b());
}

void LedController::set_b(uint8_t b) {
    Serial.printf("LedController: Function: set_b, B = %d\n", b);
    set_rgb(LedMode::get_r(), LedMode::get_g(), b);
}

void LedController::set_hsv(uint8_t hue, uint8_t saturation, uint8_t value) {
    Serial.printf("LedController: Function: set_hsv, H = %d, S = %d, V = %d\n", hue, saturation, value);
    if (!led_mode->is_done()){
        Serial.println("LedController: Still changing previous color");
        return;
    }
    if (hue == LedMode::get_hue() && saturation ==LedMode::get_sat() && value == LedMode::get_val()){
        Serial.println("LedController: HSV already set");
        return;
    }
    uint8_t old_r = LedMode::get_r();
    uint8_t old_g = LedMode::get_g();
    uint8_t old_b = LedMode::get_b();
    LedMode::set_hsv(hue, saturation, value);
    LedMode::hsv_to_rgb();
    delete led_mode;
    led_mode = new ChangingColor(this, old_r, old_g, old_b, LedMode::get_r(), LedMode::get_g(), LedMode::get_b(), get_config_value("color_transition_delay"));
    memory->write_rgb(LedMode::get_r(), LedMode::get_g(), LedMode::get_b());
}

void LedController::set_hue(uint8_t hue) {
    set_hsv(hue, LedMode::get_sat(), LedMode::get_val());
}

void LedController::set_sat(uint8_t saturation) {
    set_hsv(LedMode::get_hue(), saturation, LedMode::get_val());
}

void LedController::set_val(uint8_t value) {
    set_hsv(LedMode::get_hue(), LedMode::get_sat(), value);
}

void LedController::set_brightness(uint8_t new_brightness) {
    Serial.printf("LedController: Function: set_brightness, brightness = %d\n", new_brightness);
    if(brightness->get_target_value() == new_brightness){
        Serial.println("LedController: Function: set_brightness: Already set to this value.");
        return;
    }
    if (memory->read_state()) {
        brightness->set_brightness(new_brightness);
    }
    memory->write_brightness(new_brightness);
}

void LedController::set_state(byte state){
    if((state && memory->read_state()) || (!state && !memory->read_state()))
        return;

    if(state)
        turn_on();
    else
        turn_off();
}

void LedController::turn_on() {
    Serial.println("LedController: Function: turn_on");
    if(memory->read_state()){
        Serial.println("Already on");
        return;
    }
    brightness->set_brightness(memory->read_brightness());
    memory->write_state(1);
}

void LedController::turn_off() {
    Serial.println("LedController: Function: turn_off");
    if(!memory->read_state()){
        Serial.println("Already off");
        return;
    }
    brightness->set_brightness(0);
    memory->write_state(0);
}

void LedController::fill_all(uint8_t r, uint8_t g, uint8_t b) {
//    Serial.printf("LedController: Function: fill_all, R = %d, G = %d, B = %d\n", r, g, b);
    for (int i = 0; i < num_led; i++) {
        set_all_strips_pixel_color(i, r, g, b);
    }
    led_strip->show();
}

void LedController::set_all_strips_pixel_color(uint16_t i, uint8_t r, uint8_t g, uint8_t b) {
    uint8_t min_led_value = static_cast<uint8_t>(brightness->get_current_value() ? 1 : 0); //0 or 1
    uint8_t dimmed_r = LedMode::get_r() ? max(min_led_value, static_cast<uint8_t>((static_cast<uint16_t>(r) * brightness->get_current_value()) / 255)) : 0;
    uint8_t dimmed_g = LedMode::get_g() ? max(min_led_value, static_cast<uint8_t>((static_cast<uint16_t>(g) * brightness->get_current_value()) / 255)) : 0;
    uint8_t dimmed_b = LedMode::get_b() ? max(min_led_value, static_cast<uint8_t>((static_cast<uint16_t>(b) * brightness->get_current_value()) / 255)) : 0;
//    Serial.printf("LedController: set_all_strips_pixel_color: fill_all, R = %d, G = %d, B = %d, Br=%d\n", dimmed_r, dimmed_g, dimmed_b, brightness->get_current_value());

    led_strip->setPixelColor(i, dimmed_r, dimmed_g, dimmed_b);
//    if (is_zigzag_config) {
//        led_strip->setPixelColor(num_led - i - 1, r, g, b);
//    }
}

