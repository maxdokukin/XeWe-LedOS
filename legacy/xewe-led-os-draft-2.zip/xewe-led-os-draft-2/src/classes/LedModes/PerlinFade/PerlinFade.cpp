#include "PerlinFade.h"


PerlinFade::PerlinFade(LedController* controller)
    : LedMode(controller) {

    led_controller = controller;

    timer = new AsyncTimer<uint16_t>(LedMode::get_hue() * 255, LedMode::get_hue() * 255, get_config_value("perlin_hue_transition_delay"));

    hue_gap = get_config_value("perlin_hue_gap");
    fire_step = get_config_value("perlin_fire_step");
    min_bright = get_config_value("perlin_min_bright");
    max_bright = get_config_value("perlin_max_bright");
    min_sat = get_config_value("perlin_min_sat");
    max_sat = get_config_value("perlin_max_sat");
    half_hue_gap = hue_gap / 2;

    adjusted_hue_gap = hue_gap;
    adjusted_hue_gap_half = adjusted_hue_gap / 2;
}

void PerlinFade::frame() {
//    for (int i = 0; i < led_controller->num_led; i++) {
//        uint32_t color = get_fire_color(inoise8(i * fire_step, counter));
//
//        uint8_t r = (color >> 16) & 0xFF;
//        uint8_t g = (color >> 8) & 0xFF;
//        uint8_t b = color & 0xFF;
//
//        led_controller->set_all_strips_pixel_color(i, r, g, b);
//    }
//    counter += 5;
}

bool PerlinFade::is_done() {
    return false;
}

uint8_t PerlinFade::get_mode_id() {
    return 4;
}

long PerlinFade::get_fire_color(uint8_t val) {
//    return led_controller->led_strip->ColorHSV(
//        timer->get_current_value() - adjusted_hue_gap_half + map(val, 0, 255, 0, adjusted_hue_gap),
//        constrain(map(val, 0, 255, max_sat, min_sat), 0, 255),
//        constrain(map(val, 0, 255, min_bright, max_bright), 0, 255)
//    );
}
