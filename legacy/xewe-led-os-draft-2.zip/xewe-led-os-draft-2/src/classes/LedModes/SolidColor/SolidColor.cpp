#include "SolidColor.h"

SolidColor::SolidColor(LedController* controller)
    : LedMode(controller) {
}

SolidColor::SolidColor(LedController* controller, uint8_t r, uint8_t g, uint8_t b)
    : LedMode(controller) {
    LedMode::set_rgb(r, g, b);
}

void SolidColor::frame() { led_controller->fill_all(LedMode::get_r(), LedMode::get_g(), LedMode::get_b()); }

bool SolidColor::is_done() { return true; }

uint8_t SolidColor::get_mode_id() { return 1; }
