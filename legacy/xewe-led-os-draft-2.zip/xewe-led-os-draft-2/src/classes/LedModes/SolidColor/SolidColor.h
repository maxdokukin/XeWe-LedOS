#ifndef SOLIDCOLOR_H
#define SOLIDCOLOR_H

#include "../LedMode.h"
#include "../../LedController/LedController.h"

class SolidColor : public LedMode {
public:
    SolidColor(LedController* controller);
    SolidColor(LedController* controller, uint8_t r, uint8_t g, uint8_t b);

    void frame() override;
    bool is_done() override;
    uint8_t get_mode_id() override;
};

#endif  // SOLIDCOLOR_H
