#ifndef CHANGINGCOLOR_H
#define CHANGINGCOLOR_H

#include "../LedMode.h"
#include "../../LedController/LedController.h"

class ChangingColor : public LedMode {
private:
    AsyncTimerArray* timer;

public:
    ChangingColor(LedController* controller, uint8_t current_r, uint8_t current_g, uint8_t current_b, uint8_t target_r, uint8_t target_g, uint8_t target_b, uint32_t time);

    void frame() override;
    bool is_done() override;
    uint8_t get_mode_id() override;
};

#endif  // CHANGINGCOLOR_H
